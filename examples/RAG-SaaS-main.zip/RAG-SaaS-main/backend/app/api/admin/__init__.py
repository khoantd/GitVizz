from .route import admin_router

__all__ = ["admin_router"]