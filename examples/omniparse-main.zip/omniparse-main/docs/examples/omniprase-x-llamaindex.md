# OmniPrase x LlamaIndex

Example coming soon
